// DemoTest.java
import static org.junit.Assert.*;
import org.junit.Test;

public class DemoTest {

    private final Demo demo = new Demo();

    @Test
    public void testAdd() {
        assertEquals(5, demo.add(2, 3));
    }

    @Test
    public void testSubtract() {
        assertEquals(1, demo.subtract(3, 2));
    }

    @Test
    public void testMultiply() {
        assertEquals(6, demo.multiply(2, 3));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDivideByZero() {
        demo.divide(5, 0);
    }

    @Test
    public void testDivide() {
        assertEquals(2, demo.divide(6, 3));
    }
}