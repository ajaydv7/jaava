// DemoTest.java
import static org.junit.Assert.*;
import org.junit.Test;

public class DemoTest {

    private final Demo demo = new Demo();

    @Test
    public void Search1() {

    	System.out.println("We are currently on the following URL" + driver.getCurrentUrl());
		Thread.sleep(3000);
		
		WebElement courseName = driver.findElement(By.xpath("//input[@name='clubName']"));
		courseName.sendKeys("peb");
		
		WebElement courseState = driver.findElement(By.xpath("//select[@name='StateName']"));
		Select courseStateValue = new Select(courseState);
		courseStateValue.selectByValue("US-NJ");
		
		WebElement clickSubmit = driver.findElement(By.xpath("//input[@name='myButton']"));
		clickSubmit.click();
		Thread.sleep(5000);
        
    }
}