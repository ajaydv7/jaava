package NRCD.Nrcdbnew;
 
import java.time.Duration;
 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
 
public class HelloWorld {
 
	WebDriver driver;
 
	@BeforeClass
	public void testSetup() {
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
	}
 
	@BeforeMethod
	public void openBrowser() {
		driver.get("https://www.redbus.in/");
	}
 
	@Test(description = "Automating single flow")
	public void Search1() throws Exception {
 
		System.out.println("We are currently on the following URL" + driver.getCurrentUrl());
		Thread.sleep(3000);
 
	}
	@AfterMethod
	public void postSignUp()
	{
	System.out.println(driver.getCurrentUrl());
 
	}
 
	@AfterClass
	public void afterClass()
	{
	driver.quit();
	}
 
}
