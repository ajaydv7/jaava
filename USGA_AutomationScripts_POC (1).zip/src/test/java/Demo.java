package NRCD.Nrcdbnew;
 
import java.time.Duration;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
 
public class Demo {
 
	WebDriver driver;
 
	@BeforeClass
	public void testSetup() {
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
	}
 
	@BeforeMethod
	public void openBrowser() {
		driver.get("https://ncrdbnew-qa.azurewebsites.net/");
	}
 
	@Test(description = "Automating single flow")
	public void Search1() throws Exception {
 
		System.out.println("We are currently on the following URL" + driver.getCurrentUrl());
		Thread.sleep(3000);
 
		WebElement courseName = driver.findElement(By.xpath("//input[@name='clubName']"));
		courseName.sendKeys("peb");
 
		WebElement courseState = driver.findElement(By.xpath("//select[@name='StateName']"));
		Select courseStateValue = new Select(courseState);
		courseStateValue.selectByValue("US-NJ");
 
		WebElement clickSubmit = driver.findElement(By.xpath("//input[@name='myButton']"));
		clickSubmit.click();
		Thread.sleep(5000);
 
	}
 
	@Test(description = "Automating single flow")
	public void Search2() throws Exception {
 
		WebElement courseName = driver.findElement(By.xpath("//input[@name='clubName']"));
		courseName.clear();
		courseName.sendKeys("ale");
 
		WebElement courseState = driver.findElement(By.xpath("//select[@name='StateName']"));
		Select courseStateValue = new Select(courseState);
		courseStateValue.selectByValue("US-CA");
 
		WebElement clickSubmit = driver.findElement(By.xpath("//input[@name='myButton']"));
		clickSubmit.click();
		Thread.sleep(5000);
	}
 
	@Test(description = "Automating single flow")
	public void Search3() throws Exception {
 
		WebElement courseName = driver.findElement(By.xpath("//input[@name='clubNam']"));
		courseName.clear();
		courseName.sendKeys("ddd");
 
		WebElement clickSubmit = driver.findElement(By.xpath("//input[@name='myButton']"));
		clickSubmit.click();
		Thread.sleep(5000);
 
//		String errorMessage = driver.findElement(By.xpath("//*[@id='spnCourseDataError' and @class ='error']"))
//				.getText();
//		System.out.println(errorMessage);
//		if (errorMessage.contains("Sorry")) {
//			System.out.println("Please enter correct value in Course Name");
		}
 
	
 
	@AfterMethod
	public void postSignUp() {
		System.out.println(driver.getCurrentUrl());
 
	}
 
	@AfterClass
	public void afterClass() {
		driver.quit();
	}
 
}